# This file was automatically created by FeynRules 1.7.80
# Mathematica version: 7.0 for Mac OS X x86 (64-bit) (November 11, 2008)
# Date: Fri 5 Oct 2012 11:49:27


from object_library import all_orders, CouplingOrder


HIG = CouplingOrder(name = 'HIG',
                    expansion_order = 99,
                    hierarchy = 2)

QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

HIW = CouplingOrder(name = 'HIW',
                    expansion_order = 99,
                    hierarchy = 1)

